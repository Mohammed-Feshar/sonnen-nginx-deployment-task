{{/*
common envs fucntion
example usage:

envVars:
  standard:
    - name: MY_ENV_VAR_NAME
      value: "some value"
  fromSecret:
    - name: MY_SECRET_ENV
      secret:
        name: secret-name
        key: password
        isOptional: false #defines if the secret is required to exist.

*/}}
{{- define "channels-library.envs" -}}
{{- if .envs.fromSecret -}}
{{- range .envs.fromSecret }}
- name: {{ .name }}
  valueFrom:
    secretKeyRef:
      name: {{ .secret.name }}
      key: {{ .secret.key }}
      optional: {{ .secret.isOptional | default false  }}
{{- end }}
{{- end -}}
{{- range .envs.standard }}
- name: {{ .name }}
  value: {{ .value | quote }}
{{- end }}

{{- end -}}