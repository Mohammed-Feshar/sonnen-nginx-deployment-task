{{- define "channels-library.service" -}}
apiVersion: v1
kind: Service
metadata:
  namespace: {{ .Release.Namespace }}
  name: {{ include "channels-library.fullname" . }}
  labels:
    {{- include "channels-library.labels" . | nindent 4 }}
spec:
  type: {{ .Values.service.type }}
  ports:
    - port: {{ .Values.service.port }}
      targetPort: {{ .Values.service.targetPort | default "http" }}
      protocol: {{ .Values.service.protocol | default "TCP" }}
      name: {{ .Values.service.name | default "http" }}
  {{- range .Values.service.additionalPorts }}
    - port: {{ .port }}
      targetPort: {{ .targetPort }}
      protocol: {{ .protocol | default "TCP" }}
      name: {{  .portName }}
  {{- end }}
  selector:
    {{- include "channels-library.selectorLabels" . | nindent 4 }}

{{- end -}}