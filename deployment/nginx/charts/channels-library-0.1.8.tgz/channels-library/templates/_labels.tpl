{{- define "channels-library.labels" -}}
{{- if .Values.commonLabels }}
{{- tpl ( toYaml .Values.commonLabels ) . }}
{{- end }}
{{- end -}}