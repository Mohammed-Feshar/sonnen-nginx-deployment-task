{{- define "channels-library.annotations" -}}
{{- if .Values.commonAnnotations }}
{{- tpl (toYaml .Values.commonAnnotations) . }}
{{- end }}
{{- end -}}


