{{/*
common template for containers
@param .root the root scope
@param .image the scope of the image
*/}}
{{- define "channels-library.containers" -}}
{{ $ := .root }}
- name: {{ .image.name | default .root.Chart.Name }}
  {{- if $.Values.securityContext }}
  securityContext:
    {{- toYaml $.Values.securityContext | nindent 4 }}
  {{- end }}
  image: "{{ .image.repository }}:{{ default "latest" .image.tag }}"
  imagePullPolicy: {{ .image.pullPolicy }}
  {{- if $.Values.command }}
  command:
  {{- range $.Values.command  }}
    - {{ . | quote }}
  {{- end }}
  {{- end }}
  {{- if $.Values.args }}
  args:
  {{- range $.Values.args  }}
    - {{ . | quote }}
  {{- end }}
  {{- end }}
  {{- if $.Values.volumeMounts }}
  volumeMounts:
    {{- toYaml $.Values.volumeMounts | nindent 4 }}
  {{- end }}
  {{- if or .image.envVars $.Values.envVars }}
  {{ $envVars := coalesce .image.envVars $.Values.envVars }}
  env:
    {{- include "channels-library.envs" (dict "root" $ "envs" $envVars) | nindent 4 }}
  {{- end }}
  {{- if $.Values.service }}
  ports:
    - name: {{ $.Values.service.name | default "http" }}
      containerPort: {{ $.Values.service.targetPort | default $.Values.service.port }}
      protocol: {{ $.Values.service.protocol | default "TCP" }}
  {{- range $.Values.service.additionalPorts }}
    - name: {{  .portName }}
      containerPort: {{ .targetPort | default .port }}
      protocol: {{ .protocol | default "TCP" }}

  {{- end }}
  {{- end }}
  resources:
    {{- toYaml $.Values.resources | nindent 4 }}

{{- end -}}