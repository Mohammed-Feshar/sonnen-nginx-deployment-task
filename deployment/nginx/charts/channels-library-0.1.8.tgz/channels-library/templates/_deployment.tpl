{{- define "channels-library.deployment" -}}
apiVersion: apps/v1
kind: Deployment
metadata:
  name : {{ include "channels-library.fullname" . }}
  annotations:
    {{- include "channels-library.annotations" . | nindent 4 }}
  labels:
    {{- include "channels-library.labels" . | nindent 4 }}
  namespace: {{ .Release.Namespace }}
spec:
  replicas: {{ .Values.replicaCount | default 1 }}
  selector:
    matchLabels:
      {{- include "channels-library.labels" . | nindent 6}}
  {{- if .Values.updateStrategy }}
  strategy: {{- toYaml .Values.updateStrategy | nindent 4 }}
  {{- end }}
  template:
    metadata:
      labels:
        {{- include "channels-library.labels" . | nindent 8 }}
      annotations:
        {{- include "channels-library.annotations" . | nindent 8 }}
    spec:
      automountServiceAccountToken: {{ .Values.automountServiceAccountToken | default true }}
      {{- if .Values.image.secrets}}
      imagePullSecrets:
        {{- toYaml .Values.image.secrets | nindent 8 }}
      {{- end }}
      {{- if .Values.initContainers }}
      initContainers:
        {{- range $key, $value := .Values.initContainers }}
        {{- include "channels-library.containers"  ( dict "image" $value "root" $ ) | nindent 8 }}
        {{- end }}
      {{- end }}
      {{- if .Values.volumes}}
      volumes:
        {{- toYaml .Values.volumes | nindent 8 }}
      {{- end }}
      containers:
        {{- include "channels-library.containers"  ( dict "image" .Values.image "root" $ ) | nindent 8 }}
        {{- if .Values.image.sidecars }}
        {{- range $key, $value := .Values.image.sidecars }}
        {{- include "channels-library.containers"  ( dict "image" $value "root" $ ) | nindent 8 }}
        {{- end }}
        {{- end }}
      {{- with .Values.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- if .Values.affinity }}
      affinity:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}

{{- end }}
