# Channels Library

if you update any of the templates in this library please run the following.

```shell
helm dependency update
```
or when packaging charts manke sure you use the -u switch
```shell
helm package -u chart-name
```

## Templates
This library contains many helper templates that can be useful when creating charts that share structures, for this reason I have
created these helper templates and functions.

| helper template  | description                                | example                                                                                                    |
|------------------|--------------------------------------------|------------------------------------------------------------------------------------------------------------|
| _deployment.tpl  | main template that generates a deployment  | <pre lang="yaml"> {{ include "channels-library.deployment" . }} </pre>                                     |
| _containers.tpl  | main template that generates a image block | <pre lang="yaml"> {{ include "channels-library.containers" \(dict "image" .image.scope "root" \$\) }} </pre> |
| _annotations.tpl | main template that generates a image block |                                                                                                            |

## Properties

| Name                                   | Description                                                   | Default Value |
|----------------------------------------|---------------------------------------------------------------|---------------|
| replicaCount                           | number of replicas                                            | 1             |
| image.repository                       | repo of the image                                             | nginx         |
| image.pullPolicy                       | how the image is to be pulled                                 | IfNotPresent  | 
| image.tag                              | the tag of the image to deploy                                |
| imagePullSecrets                       |                                                               |               |
| nameOverride                           | string to partially override common name                      |               |
| fullNameOverride                       | string to fully override name                                 |               |
| envVars.standard                       | array of name, value pairs to create env vars                 | []            |
| envVars.standard.name                  |                                                               |               |
| envVars.standard.value                 |                                                               |               |                   
| envVars.fromSecret                     | array of envVars to create from secrets                       | []            |
| envVars.fromSecret.name                |                                                               |               | 
| envVars.fromSecret.secret              |                                                               | {}            |
| envVars.fromSecret.secret.name         |                                                               |               |
| envVars.fromSecret.secret.key          |                                                               |               |
| envVars.fromSecret.secret.isOptional   |                                                               | false         |
| envVars.fromConfig                     | array of envVars to create from config                        |               | 
| resource.limits.cpu                    | the maximum cpu possible for the pod                          |               |
| resource.limits.memory                 | the maximum allocatable memory possible for the pod           |               |
| resource.requests.cpu                  | the requested amount of CPU allocated to the pod              |               |
| resource.requests.memory               | the requested amount of memory allocated to the pod           |               |
| commonAnnotations                      | annotations that will be applied to all resources (templated) | {}            |
| commonLabels                           | labels that will be applied to all resources (templated)      | {}            |
| podAnnotations                         | annotations that will be applied to the pod                   | {}            |
| service.type                           | service type, ClusterIP, NodePort etc                         | ClusterIP     |
| service.port                           | port of the service                                           | 80            |
| service.targetPort                     | target port                                                   |               |
| volumes                                |                                                               | []            |
| volumes.name                           | name of the volume                                            |               |
| volumes.secret.secretName              | secret to use for the volume                                  |               |
| volumes.configMap.name                 | config map to use for volume                                  |               |            
| volumeMounts                           |                                                               | []            | 
| volumeMounts.mountPath                 |                                                               |               |
| volumeMounts.subPath                   |                                                               |               |
| volumeMounts.name                      |                                                               |               |



## example values.yaml

```yaml
# Default values for channels-microservices.
# This is a YAML-formatted file.
# Declare variables to be passed into your templates.
replicaCount: 1
image:
  repository: nginx
  pullPolicy: IfNotPresent
  # Overrides the image tag whose default is the chart appVersion.
  tag: ""

imagePullSecrets: []
nameOverride: "channels-ms"
fullnameOverride: "channels-ms"

envVars:
  standard:
    - name: ENV_VAR_A
      value: someValue
    - name: ENV_VAR_B
      value: someOtherValue
  fromSecret:
    - name: MY_SECRET_ENV_VAR
      secret:
        name: my-kube-secret
        key: my-kube-secret-key
        isOptional: false #defines if the secret is required to exist.
   

serviceAccount:
  # Specifies whether a service account should be created
  create: true
  # Annotations to add to the service account
  annotations: {}
  # The name of the service account to use.
  # If not set and create is true, a name is generated using the fullname template
  name: ""

podAnnotations: {}

service:
  type: ClusterIP
  port: 80
  
ingress:
  enabled: false
  #className: "nginx-internal"
  #annotations: {}
  #hosts:
  #  - host: persistence.dev.nginx.sonnen.com
  #    paths:
  #      - path: /*
  #        pathType: ImplementationSpecific
  #        name: testname
  #        portNumber: 8888
  #  - host: test
  #    paths:
  #      - path: /*
  #        pathType: ImplementationSpecific
  #        portName: testportname
  #tls: []
  #  - secretName: chart-example-tls
  #    hosts:
  #      - chart-example.local

resources: 
  limits:
    cpu: 100m
    memory: 128Mi
  requests:
    cpu: 100m
    memory: 128Mi
    
volumes:
  - name: log4j2
    secret:
      secretName: log4j2
  - name: application-config
    configMap:
      name: application-config-productadapter-ms

volumeMounts:
  - mountPath: /app/config/application.properties
    subPath: application.properties
    name: application-config
  - mountPath: /app/config/log4j2.xml
    subPath: log4j2.xml
    name: log4j2

autoscaling:
  enabled: false
  minReplicas: 1
  maxReplicas: 100
  targetCPUUtilizationPercentage: 80
  # targetMemoryUtilizationPercentage: 80


```

To test out the template with the values file you can run the following command

```shell
helm template channels-microservice -f channels-microservice/values.yaml
```

### Templates
Within channels library we have a few full templates, these are helpers that create kubernetes resources in full.
#### deployment (_deployments.tpl)
in your chart/templates folder create a deployment.yaml file and add the following:
```kubernetes helm
{{- include "channels-library.deployment" . }}
```
#### ingress (_ingress.tpl)

#### Horizontal Pod Autoscaler (_hpa.tpl)

#### service (_service.tpl)